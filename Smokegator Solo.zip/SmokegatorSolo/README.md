# SmokegatorSolo
Single user version of Smokegator wildfire smoke pelengation app.
